#ifndef H_ARC4RANDOM_BUF
#define H_ARC4RANDOM_BUF

void
arc4random_buf(void *buf, size_t n);

#endif