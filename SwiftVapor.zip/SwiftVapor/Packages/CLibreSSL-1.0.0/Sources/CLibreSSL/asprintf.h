#ifndef H_ASPRINTF
#define H_ASPRINTF

int asprintf(char **str, const char *fmt, ...);

#endif
