/* $OpenBSD$ */
/* Ted Unangst places this file in the public domain. */

#include "include/crypto.h"

void
OPENSSL_init(void)
{

}
